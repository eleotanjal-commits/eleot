export default async (req) => {
  try {
    if (req.method !== "POST") {
      return new Response("Method Not Allowed", { status: 405 });
    }

    const body = await req.json();
    const {
      lesson_description,
      teacher_name,
      subject,
      grade,
      segment,
      visit_date,
      lang = "ar",
    } = body || {};

    if (!lesson_description || !teacher_name || !subject) {
      return new Response(
        JSON.stringify({ error: "Missing required fields" }),
        { status: 400, headers: { "Content-Type": "application/json" } }
      );
    }

    const OPENAI_API_KEY = process.env.OPENAI_API_KEY; // Netlify Env
    if (!OPENAI_API_KEY) {
      return new Response(
        JSON.stringify({ error: "Server missing OPENAI_API_KEY" }),
        { status: 500, headers: { "Content-Type": "application/json" } }
      );
    }

    const system = `
You are an expert ELEOT evaluator.
Return STRICT JSON ONLY.
Score each environment A..G as numbers with max=4.
Each environment must include: env_code, env_score, env_max, justification_ar, evidence_ar, recommendations_ar.
Also return overall_recommendations_ar (string).
No extra text outside JSON.
`;

    const user = `
Teacher: ${teacher_name}
Subject: ${subject}
Grade: ${grade || ""}
Segment: ${segment || ""}
Visit Date: ${visit_date || ""}

Lesson Description (Arabic text possible):
${lesson_description}

Evaluate ELEOT environments A..G:
A Equitable Learning
B High Expectations
C Supportive Learning
D Active Learning
E Progress Monitoring & Feedback
F Well-Managed Learning
G Digital Learning

Return JSON with:
{
  "provider": "openai",
  "model": "<model_name>",
  "environments": [
    {
      "env_code":"A",
      "env_score": 0-4,
      "env_max": 4,
      "justification_ar": "...",
      "evidence_ar": "...",
      "recommendations_ar": "..."
    }
  ],
  "overall_recommendations_ar":"..."
}
`;

    const payload = {
      model: "gpt-4o-mini", // غيّرها حسب خطتك
      messages: [
        { role: "system", content: system },
        { role: "user", content: user },
      ],
      temperature: 0.2,
      response_format: { type: "json_object" },
    };

    const r = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${OPENAI_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    });

    if (!r.ok) {
      const t = await r.text();
      return new Response(
        JSON.stringify({ error: "AI request failed", detail: t }),
        { status: 502, headers: { "Content-Type": "application/json" } }
      );
    }

    const data = await r.json();
    const content = data?.choices?.[0]?.message?.content;
    let parsed;
    try {
      parsed = JSON.parse(content);
    } catch {
      return new Response(
        JSON.stringify({ error: "AI returned non-JSON", raw: content }),
        { status: 502, headers: { "Content-Type": "application/json" } }
      );
    }

    // add provider/model
    parsed.provider = parsed.provider || "openai";
    parsed.model = parsed.model || payload.model;

    return new Response(JSON.stringify(parsed), {
      status: 200,
      headers: { "Content-Type": "application/json" },
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: e.message || "Unknown error" }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }
};


