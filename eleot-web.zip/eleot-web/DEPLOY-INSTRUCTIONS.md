# تعليمات النشر على Netlify - Drag and Drop

## ⚠️ ملاحظة مهمة:

عند استخدام Drag and Drop، يجب رفع **المشروع الكامل** وليس فقط مجلد `dist`، لأن Netlify يحتاج:
- `netlify/functions/` - للـ Functions
- `netlify.toml` - للإعدادات
- `package.json` - لبناء المشروع

## ✅ الطريقة الصحيحة:

### الخيار 1: رفع المشروع الكامل (موصى به)

1. **تأكد من أن `.env` غير موجود في المشروع** (يجب أن يكون في `.gitignore`)

2. **ارفع المشروع الكامل:**
   - اذهب إلى [Netlify Drop](https://app.netlify.com/drop)
   - اسحب **المجلد الرئيسي للمشروع** (eleot-web)
   - أفلته في Netlify

3. **Netlify سيقوم تلقائياً:**
   - قراءة `netlify.toml`
   - تشغيل `npm install`
   - تشغيل `npm run build`
   - نشر مجلد `dist`
   - تفعيل Functions من `netlify/functions/`

### الخيار 2: رفع مجلد dist فقط (للتجربة السريعة)

⚠️ **تحذير:** هذه الطريقة لن تعمل مع Functions!

إذا أردت تجربة الموقع فقط بدون Functions:
1. شغّل `npm run build` محلياً
2. ارفع مجلد `dist` فقط
3. لكن AI Function لن يعمل

## 🔧 إعداد Environment Variables:

بعد النشر الأول، اذهب إلى:
**Site settings → Environment variables → Add variable**

أضف:
```
VITE_SUPABASE_URL = https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY = your-anon-key
OPENAI_API_KEY = your-openai-key
```

**مهم:** بعد إضافة Environment Variables، يجب **إعادة النشر** (Redeploy).

## 📋 Checklist قبل النشر:

- [ ] تم تشغيل `npm run build` بنجاح محلياً
- [ ] مجلد `dist` موجود
- [ ] `netlify.toml` موجود في الجذر
- [ ] `netlify/functions/ai-evaluate.js` موجود
- [ ] `.env` غير موجود (أو في `.gitignore`)
- [ ] `package.json` موجود

## 🚀 خطوات النشر:

1. **افتح Netlify Drop:**
   ```
   https://app.netlify.com/drop
   ```

2. **اسحب المجلد الكامل:**
   - اسحب مجلد `eleot-web` (المجلد الرئيسي)
   - أفلته في Netlify

3. **انتظر حتى يكتمل النشر:**
   - سترى Build logs
   - انتظر حتى يظهر "Site is live"

4. **أضف Environment Variables:**
   - Site settings → Environment variables
   - أضف المتغيرات المذكورة أعلاه

5. **أعد النشر:**
   - Deploys → Trigger deploy → Redeploy site

## 🧪 اختبار الموقع:

بعد النشر، اختبر:

1. **الصفحة الرئيسية:**
   ```
   https://your-site.netlify.app
   ```

2. **تسجيل الدخول:**
   - يجب أن يعمل Supabase Auth

3. **صفحة التقييم:**
   - أدخل بيانات زيارة
   - اضغط "قيّم باستخدام الذكاء الاصطناعي"
   - تأكد من أن Function يعمل

4. **صفحة الزيارات:**
   - احفظ زيارة
   - تأكد من ظهورها في القائمة

## 🔍 استكشاف الأخطاء:

### Build فشل:
- تحقق من Build logs في Netlify
- تأكد من أن `package.json` صحيح
- تأكد من أن `netlify.toml` موجود

### Functions لا تعمل:
- تحقق من أن `netlify/functions/ai-evaluate.js` موجود
- تحقق من Function logs في Netlify
- تأكد من `OPENAI_API_KEY` موجودة

### Environment Variables لا تعمل:
- تأكد من إعادة النشر بعد إضافة المتغيرات
- تحقق من أن الأسماء صحيحة (حساسة لحالة الأحرف)

## 📞 الدعم:

إذا واجهت مشاكل:
1. تحقق من Netlify Deploy Logs
2. تحقق من Browser Console
3. تحقق من Netlify Function Logs

